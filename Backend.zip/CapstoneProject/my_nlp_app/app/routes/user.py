from flask import Blueprint, request, jsonify
from app import db
from app.models.user import User
from werkzeug.security import generate_password_hash
from werkzeug.security import check_password_hash

user_bp = Blueprint('user', __name__, url_prefix= '/api/v1/users')

@user_bp.route('/register', methods = ['POST'])
def register():
    data = request.get_json()

    username = data.get('username')
    password =data.get('password')
    email = data.get('email')

    if not all([username, email, password]):
        return jsonify({
            "status": "error",
            "message": "입력값이 부족합니다."
        }), 400
    
    #데이터베이스 중복 확인 조건
    if User.query.filter((User.username == username) | (User.email == email)).first():
        return jsonify({
            "status": "error",
            "message": "이미 사용 중인 사용자명 또는 이메일입니다."
        }), 409
    #DB접근하고 정보 저장
    hashed_pw = generate_password_hash(password)

    new_user = User(username=username, email=email, password=hashed_pw)
    db.session.add(new_user)
    db.session.commit()
    #나중에 토큰 생성하고 넘겨줄것
    return jsonify({
        "status": "success",
        "user": {
            "id": new_user.id,
            "username": new_user.username,
            "email": new_user.email
        }
    }), 201

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()

    username = data.get('username')
    password = data.get('password')

    if not all([username, password]):
        return jsonify({
            "status": "error",
            "message": "잘못된 입력 형태입니다. 사용자 이름과 비밀번호를를 확인해주세요."
        }), 400
    
    #유저 찾기
    #유저 찾기 실패 또는 password 불일치일때
    user = User.query.filter_by(username=username).first()
    if not user or not check_password_hash(user.password, password):
        return jsonify({
            "status": "error",
            "message": "사용자 이름 또는 비밀번호가 올바르지 않습니다."
        }), 401
    

    return jsonify({
        "status": "success",
        "user": {
            "id": user.id,
            "username": user.username,
            "email": user.email
        }
    }), 200

@user_bp.route('/<userid>/recommended-posts', methods=['GET'])
def recommend(userid):
    data = request.get_json()

    keyword = data.get('keyword')
    category = data.get('category')
    limit = data.get('limit')

    if not all([keyword, category, limit]):
        return jsonify({'400 Bad Request : "status error" : 잘못된 검색 조건입니다.'}), 400


    #입력 정보 토대로 추천 리스트 생성

    return jsonify({
        'postid' : '게시물id',
        'title' : '제목',
        'thumbnail_image_url' : 'example.png',
        'description' : '설명',
        'author' : '작성자정보',
        'keyword' : '게시물 키워드',
        'category' : '게시물 카테고리',
        'viewing' : '게시물 조회수',
        'recommendation_score': '추천 점수'
    })

@user_bp.route('/<userid>/profile', methods=['GET'])
def user_profile(userid):
    #토큰,권한 확인
    #DB에서 유저 검색

    return jsonify({
        'user' : {
            'id' : '유저 고유 ID',
            'username' : 'comeon0927',
            'email' : 'user1@example.com',
            'profile_image_url' : 'user1.jpg',
            'registeredAt' : '2022-01-15',
            'current_points' : 1500,
            'current_grade' : '실버',
            'grade_icon_url' : 'silver_grade.png',
            'total_trades' : 30,
            'completed_trades' : 25,
            'cancellation_count' : 3,
            'cancellation_warning' : 'false'
        }
    })


@user_bp.route('/<userid>/trade-history',methods=['GET'])
def user_trade_history(userid):
    return "trade_history", 200

@user_bp.route('/<userid>/reviews',methods=['GET'])
def user_review(userid):
    return "reviews", 200
